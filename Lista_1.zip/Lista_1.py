############# << LISTA 1 >> #############
### Luan Rodrigues de Carvalho


# print("#"*41, "\n", sep="")

### =========== Questão 1 =========== ###
print("Questão 1\n")

alturas = []
input_recebido = input("Digite uma altura ou 'q' para sair: ")

# Loop de preenchimento da lista
while input_recebido != "q":
    try:
        altura = float(input_recebido)
        alturas.append(altura)
    except ValueError:
        print("Entrada inválida!")
    input_recebido = input("Digite uma altura ou 'q' para sair: ")

print("\nLista das alturas:", alturas)

# Função que calcula a média das alturas
def media(lista_valores):
    soma = sum(lista_valores)
    try:
        media = soma/(len(lista_valores))
        return media
    except ZeroDivisionError:
        print("Nenhuma altura foi inserida.")

# Verificação de se a lista é vazia
if alturas != []:
    media_alturas = media(alturas)
    print("A média das alturas é:", media_alturas)

print("\n", "#"*41, "\n", sep="")

### =========== Questão 2 =========== ###
print("Questão 2\n")

def abre_arquivos(path):
    try:
        with open(path) as arq1:
            arq1.read()
            print("Arquivo encontrado!")
    except FileNotFoundError:
        with open(path, 'w') as arq2:
            arq2.write('Agora este arquivo existe!')
            print("Arquivo criado!")

print("Passando um arquivo já existente:")
abre_arquivos("dir1/dir2/txt_existente.txt")

print("\nPassando um arquivo que não existe:")
abre_arquivos("dir1/dir2/txt_novo.txt")

print("\n", "#"*41, "\n", sep="")

### =========== Questão 3 =========== ###
print("Questão 3\n")
import numpy as np

def soma_listas(lista_1, lista_2):
    array_1 = np.array(lista_1)
    array_2 = np.array(lista_2)
    
    try:
        return array_1 + array_2
    except ValueError:
        return "Tamanhos não compatíveis!"

# Exemplos de aplicação da função
pares = [2, 4, 6, 8, 10]
quadrados = [1, 4, 9, 16, 25, 36, 49]
primos = [2, 3, 5, 7, 11, 13, 17]

print("Lista de quadrados: ", quadrados, "\nLista de primos: ", primos, sep="")
print("Soma de quadrados com primos: ", soma_listas(quadrados, primos), "\n", sep="")

print("Lista de pares: ", pares, "\nLista de quadrados: ", quadrados, sep="")
print("Soma de pares com quadrados: ", soma_listas(pares, quadrados), sep="")

print("\n", "#"*41, "\n", sep="")

## =========== Questão 4 =========== ###
print("Questão 4\n")

def verifica_listas(lista_nomes):
    numeros = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    caracteres_proibidos = ['"', '!', '@', '#', '$', '%', '¨', '&', '*', '(', ')',
                        '_', '+', '=', '-', '{', '}', '[', ']', '|', ':', ';',
                        '<', '>', ',', '.', '?', '/']
    
    # Vamos verificar cada nome da lista
    for nome in lista_nomes:
        if type(nome) != str: # Primeira exceção: o elemento não é uma string
            raise Exception(f"Este nome não é uma string: {nome}")
        
        # Se o nome for uma string, ótimo; mas ainda temos que verificar se ele contém caracteres inválidos
        else:
            # Vamos percorrer cada caractere da string procurando irregularidades    
            for caracter in nome:
                if caracter in numeros: # Segunda exceção: o nome contém números
                    raise Exception(f"Este nome contém números: {nome}")
                elif caracter in caracteres_proibidos: # Terceira exceção: o nome contém caracteres inválidos
                    raise Exception(f"Este nome contém caracteres inválidos: {nome}")

# Exemplo de aplicação
lista_1 = ["Hidrogênio", "H#lio", "Lítio", ["Berílio", "Boro", "C@rbono", "Nitrogênio"],
            "0xigênio", "Flúor", "Neônio', 'Sódio', 'Magnésio", ("A|umínio", "Silício",
            "Fósforo"), "&nxofre", "Cloro",
            """                                     ÔÔ
                                                  ÔÔ  ÔÔ
                                                ÔÔ      ÔÔ
                AA      RRRRRRRR      GGGGGG      ÔÔÔÔÔÔ    NN      NN  IIIIII    OOOOOO  
                AA      RRRRRRRR      GGGGGG      ÔÔÔÔÔÔ    NN      NN  IIIIII    OOOOOO  
              AA  AA    RR      RR  GG      GG  ÔÔ      ÔÔ  NNNN    NN    II    OO      OO
              AA  AA    RR      RR  GG      GG  ÔÔ      ÔÔ  NNNN    NN    II    OO      OO
            AA      AA  RR      RR  GG          ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AA      AA  RR      RR  GG          ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AAAAAAAAAA  RRRRRRRR    GG  GGGGGG  ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AAAAAAAAAA  RRRRRRRR    GG  GGGGGG  ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AA      AA  RR      RR  GG      GG  ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AA      AA  RR      RR  GG      GG  ÔÔ      ÔÔ  NN  NN  NN    II    OO      OO
            AA      AA  RR      RR  GG      GG  ÔÔ      ÔÔ  NN    NNNN    II    OO      OO
            AA      AA  RR      RR  GG      GG  ÔÔ      ÔÔ  NN    NNNN    II    OO      OO
            AA      AA  RR      RR    GGGGGG      ÔÔÔÔÔÔ    NN      NN  IIIIII    OOOOOO  
            AA      AA  RR      RR    GGGGGG      ÔÔÔÔÔÔ    NN      NN  IIIIII    OOOOOO  
            """]
lista_2 = ["Lorem", "ipsum", "dolor", "sit", "amet"]

print("Verificando a lista_1:")
try:
    verifica_listas(lista_1)
    print("Tudo certo! =)")
except Exception as e:
    print("Oops...")
    print(e, "\n")

print("Verificando a lista_2:")
try:
    verifica_listas(lista_2)
    print("Tudo certo! =)")
except Exception as e:
    print("Há um problema com esta lista.")
    print(e)

print("\n", "#"*41, "\n", sep="")

### =========== Questão 5 =========== ###
print("Questão 5\n")

def fatorial(n):
    # Para esta função, utilizei a fórmula n! = (n+1)! / (n+1)
    if type(n) != int:
        return "O argumento da função deve ser inteiro."
    elif n < 0:
        return "O inteiro não pode ser negativo."
    else:
        n_fatorial = n+1
        contador = n
        while contador > 1:
            n_fatorial *= contador
            contador -= 1
        return int(n_fatorial/(n+1))

print("Fatorial de 6:", fatorial(6))
print("Fatorial de -3:", fatorial(-3))
print("Fatorial de 4.71:", fatorial(4.71))
print("Fatorial de 'Quatro':", fatorial('Quatro'))

print("\n", "#"*41, "\n", sep="")